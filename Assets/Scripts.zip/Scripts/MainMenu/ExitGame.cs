using UnityEngine;

namespace MainMenu
{
    public class ExitGame : MonoBehaviour
    {
        public void Quit()
        {
            Application.Quit();
        }
    }
}
