using UnityEngine;

namespace MainMenu
{
    public class Authors : MonoBehaviour
    {

    }
}
